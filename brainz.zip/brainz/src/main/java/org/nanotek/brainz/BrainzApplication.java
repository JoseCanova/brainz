package org.nanotek.brainz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrainzApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrainzApplication.class, args);
	}

}
