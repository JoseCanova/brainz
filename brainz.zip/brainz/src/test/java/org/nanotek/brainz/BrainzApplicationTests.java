package org.nanotek.brainz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainzApplicationTests {

	@Test
	void contextLoads() {
	}

}
